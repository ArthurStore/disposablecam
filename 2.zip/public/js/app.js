/* ═══════════════════════════════════════
   Disposable Camera — Main App Logic
   ═══════════════════════════════════════ */

(function () {
  'use strict';

  const BASE = (function () {
    const p = window.location.pathname;
    return p.endsWith('/') ? p : p.replace(/\/[^/]*$/, '/');
  })();
  const api = (rel) => BASE + 'api/' + rel.replace(/^\//, '');
  const url = (rel) => BASE + rel.replace(/^\//, '');

  // ─── State ───
  let currentUser = null;
  let currentFacingMode = 'environment';
  let mediaStream = null;
  let currentMode = 'photo';
  let isRecording = false;
  let mediaRecorder = null;
  let recordedChunks = [];
  let longPressTimer = null;
  let mirrorOverride = null;
  let recStart = 0;
  let recTimerId = null;
  let flashMode = 'off';
  let zoomLevel = 1;
  let nativeZoomActive = false;
  let currentZoomPreset = 1;
  let lastTapTime = 0;
  let pinchStartDist = 0;
  let pinchStartZoom = 1;
  let pendingCapture = null;

  // Settings state
  let gridEnabled = false;
  let timerSeconds = 0;
  let continuousMode = false;
  let timerActive = false;
  let timerCountdownId = null;

  // Draft queue — each item: {blob, filename, mimetype, objUrl, caption, snapBarY}
  let draftQueue = [];
  let draftViewIndex = 0;

  // Moments counter
  let momentsCaptured = 0;

  // Timelapse — record video then server speed-up
  let tlIntervalId = null;
  let tlCapturing = false;
  let tlMediaRecorder = null;
  let tlRecordedChunks = [];
  let tlRecStart = 0;

  // Snap caption bar drag state (single review)
  let snapBarDragging = false;
  let snapBarStartY = 0;
  let snapBarStartTop = 0;
  let snapBarY = 50; // percent

  // Draft snap bar drag state
  let draftSnapDragging = false;
  let draftSnapStartY = 0;
  let draftSnapStartTop = 0;

  // Focus lock (no exposure slider)
  let focusLocked = false;
  let focusBoxX = 0;
  let focusBoxY = 0;
  let isCapturing = false;

  // ─── DOM refs ───
  const registrationModal = document.getElementById('registration-modal');
  const participantInput = document.getElementById('participant-input');
  const registerBtn = document.getElementById('register-btn');
  const registerError = document.getElementById('register-error');
  const appEl = document.getElementById('app');
  const userName = document.getElementById('user-name');
  const userNumber = document.getElementById('user-number');
  const genderIcon = document.getElementById('gender-icon');
  const logoutBtn = document.getElementById('logout-btn');
  const settingsBtn = document.getElementById('settings-btn');
  const video = document.getElementById('camera-preview');
  const zoomLayer = document.getElementById('zoom-layer');
  const canvas = document.getElementById('capture-canvas');
  const captureBtn = document.getElementById('capture-btn');
  const rotateBtn = document.getElementById('rotate-btn');
  const flashBtn = document.getElementById('flash-btn');
  const recordingIndicator = document.getElementById('recording-indicator');
  const recTimer = document.getElementById('rec-timer');
  const tlIndicator = document.getElementById('timelapse-indicator');
  const tlFrameCountEl = document.getElementById('tl-frame-count');
  const galleryBtn = document.getElementById('gallery-btn');
  const galleryThumb = document.getElementById('gallery-thumb');
  const welcomeCover = document.getElementById('welcome-cover');
  const welcomeEventName = document.getElementById('welcome-event-name');
  const welcomeEventSubtitle = document.getElementById('welcome-event-subtitle');
  const galleryModal = document.getElementById('gallery-modal');
  const galleryModalClose = document.getElementById('gallery-modal-close');
  const galleryGrid = document.getElementById('gallery-grid');
  const galleryEmpty = document.getElementById('gallery-empty');
  const uploadProgress = document.getElementById('upload-progress');
  const progressFill = document.querySelector('.progress-fill');
  const mediaModal = document.getElementById('media-modal');
  const mediaModalBody = document.getElementById('media-modal-body');
  const mediaModalClose = document.getElementById('media-modal-close');
  const viewfinder = document.getElementById('viewfinder');
  const reviewScreen = document.getElementById('review-screen');
  const reviewMedia = document.getElementById('review-media');
  const reviewCaptionInput = document.getElementById('review-caption-input');
  const reviewDiscardBtn = document.getElementById('review-discard-btn');
  const reviewUploadBtn = document.getElementById('review-upload-btn');
  const reviewControls = document.getElementById('review-controls');
  const timelapseSpeedPanel = document.getElementById('timelapse-speed-panel');
  const tlSpeedSlider = document.getElementById('tl-speed-slider');
  const tlSpeedInput = document.getElementById('tl-speed-input');
  const tlSpeedValue = document.getElementById('tl-speed-value');
  const tlProcessingOverlay = document.getElementById('tl-processing-overlay');
  let reviewObjUrl = null;
  let tlProcessedBlob = null;
  let tlProcessedObjUrl = null;
  let tlProcessTimer = null;
  let tlProcessAbort = null;
  let tlProcessGen = 0;

  // In-app back navigation
  const overlayStack = [];
  let ignoreNextPop = false;
  const microToast = document.getElementById('micro-toast');
  const timerCountdownEl = document.getElementById('timer-countdown');
  const gridOverlay = document.getElementById('grid-overlay');
  const momentsCounter = document.getElementById('moments-counter');
  const momentsCount = document.getElementById('moments-count');
  const settingsPanel = document.getElementById('settings-panel');
  const settingsClose = document.getElementById('settings-close');
  const gridOff = document.getElementById('grid-off');
  const gridOn = document.getElementById('grid-on');
  const shootSingle = document.getElementById('shoot-single');
  const shootContinuous = document.getElementById('shoot-continuous');
  const draftBadge = document.getElementById('draft-badge');
  const draftCount = document.getElementById('draft-count');
  const draftReviewPanel = document.getElementById('draft-review-panel');
  const draftPanelClose = document.getElementById('draft-panel-close');
  const draftPanelCount = document.getElementById('draft-panel-count');
  const draftDiscardAll = document.getElementById('draft-discard-all');
  const draftUploadAll = document.getElementById('draft-upload-all');
  const draftViewerMedia = document.getElementById('draft-viewer-media');
  const draftSnapBar = document.getElementById('draft-snap-bar');
  const draftSnapText = document.getElementById('draft-snap-text');
  const draftViewerHint = document.getElementById('draft-viewer-hint');
  const draftPrev = document.getElementById('draft-prev');
  const draftNext = document.getElementById('draft-next');
  const draftItemCounter = document.getElementById('draft-item-counter');
  const draftDeleteCurrent = document.getElementById('draft-delete-current');
  const draftCaptionInput = document.getElementById('draft-caption-input');
  const draftUploadCurrent = document.getElementById('draft-upload-current');
  const snapCaptionBar = document.getElementById('snap-caption-bar');
  const snapCaptionText = document.getElementById('snap-caption-text');
  const snapTapHint = document.getElementById('snap-tap-hint');
  const orientationModal = document.getElementById('orientation-modal');
  const orientationUnderstandBtn = document.getElementById('orientation-understand-btn');
  const orientationDontShow = document.getElementById('orientation-dont-show');
  const focusOverlay = document.getElementById('focus-overlay');
  const focusBox = document.getElementById('focus-box');

  // ─── Audio ───
  const AudioCtx = window.AudioContext || window.webkitAudioContext;
  let audioCtx = null;

  function getAudioCtx() {
    if (!audioCtx) audioCtx = new AudioCtx();
    return audioCtx;
  }

  function playShutterSound() {
    try {
      const ctx = getAudioCtx();
      const t = ctx.currentTime;
      function click(at, freq, dur, vol) {
        const osc = ctx.createOscillator();
        const gain = ctx.createGain();
        const filter = ctx.createBiquadFilter();
        filter.type = 'bandpass'; filter.frequency.value = freq; filter.Q.value = 2;
        osc.type = 'sawtooth';
        osc.frequency.setValueAtTime(freq, at);
        osc.frequency.exponentialRampToValueAtTime(freq * 0.3, at + dur);
        gain.gain.setValueAtTime(vol, at);
        gain.gain.exponentialRampToValueAtTime(0.001, at + dur);
        osc.connect(filter); filter.connect(gain); gain.connect(ctx.destination);
        osc.start(at); osc.stop(at + dur);
      }
      click(t, 2800, 0.04, 0.35);
      click(t + 0.045, 1800, 0.06, 0.28);
      click(t + 0.12, 900, 0.08, 0.12);
      const bufSize = ctx.sampleRate * 0.05;
      const buf = ctx.createBuffer(1, bufSize, ctx.sampleRate);
      const data = buf.getChannelData(0);
      for (let i = 0; i < bufSize; i++) data[i] = (Math.random() * 2 - 1) * (1 - i / bufSize);
      const noise = ctx.createBufferSource();
      noise.buffer = buf;
      const nGain = ctx.createGain();
      nGain.gain.setValueAtTime(0.18, t);
      nGain.gain.exponentialRampToValueAtTime(0.001, t + 0.05);
      noise.connect(nGain); nGain.connect(ctx.destination); noise.start(t);
    } catch (e) {}
  }

  function playBeepSound() {
    try {
      const ctx = getAudioCtx();
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.type = 'sine'; osc.frequency.value = 1200;
      gain.gain.setValueAtTime(0.2, ctx.currentTime);
      gain.gain.exponentialRampToValueAtTime(0.01, ctx.currentTime + 0.1);
      osc.connect(gain); gain.connect(ctx.destination);
      osc.start(); osc.stop(ctx.currentTime + 0.1);
    } catch (e) {}
  }

  function playTimerBeep(isFinal) {
    try {
      const ctx = getAudioCtx();
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.type = 'sine'; osc.frequency.value = isFinal ? 1800 : 1000;
      gain.gain.setValueAtTime(0.3, ctx.currentTime);
      gain.gain.exponentialRampToValueAtTime(0.01, ctx.currentTime + (isFinal ? 0.2 : 0.08));
      osc.connect(gain); gain.connect(ctx.destination);
      osc.start(); osc.stop(ctx.currentTime + 0.2);
    } catch (e) {}
  }

  function vibrate(pattern) {
    if (navigator.vibrate) navigator.vibrate(pattern);
  }

  function showMicroToast(msg, duration) {
    microToast.textContent = msg;
    microToast.classList.remove('hidden');
    microToast.classList.add('show');
    setTimeout(() => {
      microToast.classList.remove('show');
      setTimeout(() => microToast.classList.add('hidden'), 350);
    }, duration || 2500);
  }
  window.showMicroToast = showMicroToast;

  // ─── Smart Name Truncation ───
  function truncateName(fullName) {
    if (!fullName) return '';
    const words = fullName.trim().split(/\s+/);
    if (words.length <= 2) return fullName.trim();
    const firstTwo = words.slice(0, 2).join(' ');
    const initials = words.slice(2).map((w) => w.charAt(0).toUpperCase() + '.').join(' ');
    return firstTwo + ' ' + initials;
  }

  // ─── Orientation Modal ───
  function showOrientationModal() {
    const skip = localStorage.getItem('dc_orientation_skip');
    if (skip === 'true') return;
    if (orientationModal) orientationModal.classList.remove('hidden');
  }

  function hideOrientationModal() {
    if (orientationModal) orientationModal.classList.add('hidden');
    if (orientationDontShow && orientationDontShow.checked) {
      localStorage.setItem('dc_orientation_skip', 'true');
    }
  }

  if (orientationUnderstandBtn) {
    orientationUnderstandBtn.addEventListener('click', hideOrientationModal);
  }

  // ─── Orientation layout hook ───
  function initHistoryNav() {
    if (window.__dcHistoryNav) return;
    window.__dcHistoryNav = true;
    history.replaceState({ dcRoot: true }, '');
    history.pushState({ dcGuard: true }, '');
    window.addEventListener('popstate', () => {
      if (ignoreNextPop) {
        ignoreNextPop = false;
        return;
      }
      if (overlayStack.length) {
        const { onClose } = overlayStack.pop();
        onClose();
      } else {
        history.pushState({ dcGuard: true }, '');
      }
    });
  }

  function pushOverlay(onClose) {
    overlayStack.push({ onClose });
    history.pushState({ dcOverlay: true }, '');
  }

  function dismissOverlay(onClose) {
    if (!overlayStack.length) {
      onClose();
      return;
    }
    ignoreNextPop = true;
    overlayStack.pop();
    onClose();
    history.back();
  }

  window.dismissAppOverlay = dismissOverlay;
  window.pushAppOverlay = pushOverlay;

  function updateOrientationStyles() {
    const landscape = window.innerWidth > window.innerHeight;
    document.body.classList.toggle('landscape-ui', landscape);
    if (landscape && window.isChatOpen && window.isChatOpen()) {
      if (window.dismissAppOverlay) window.dismissAppOverlay(window.closeChatPanel);
      else if (window.closeChatPanel) window.closeChatPanel();
    }
  }
  window.addEventListener('resize', updateOrientationStyles);
  window.addEventListener('orientationchange', updateOrientationStyles);

  // ─── Touch-to-Focus Lock (tap to lock, tap elsewhere or box to release) ───
  function setupFocusOverlay() {
    if (!focusOverlay || !focusBox) return;

    function releaseFocus() {
      focusLocked = false;
      focusBox.classList.remove('locked');
      focusBox.classList.add('hidden');
      releaseFocusConstraints();
    }

    function lockFocusAt(clientX, clientY) {
      const rect = viewfinder.getBoundingClientRect();
      const x = clientX - rect.left;
      const y = clientY - rect.top;
      focusBoxX = x;
      focusBoxY = y;
      focusLocked = true;
      focusBox.style.left = x + 'px';
      focusBox.style.top = y + 'px';
      focusBox.classList.remove('hidden');
      focusBox.classList.add('locked');
      vibrate(30);
      applyFocusAtPoint(x / rect.width, y / rect.height);
    }

    focusBox.addEventListener('click', (e) => {
      e.stopPropagation();
      releaseFocus();
    });

    focusOverlay.addEventListener('click', (e) => {
      if (e.target.closest('.vf-top') || e.target.closest('.vf-bottom')) return;
      e.preventDefault();
      if (focusLocked) {
        releaseFocus();
        return;
      }
      lockFocusAt(e.clientX, e.clientY);
    });

    focusOverlay.addEventListener('touchend', (e) => {
      if (e.target.closest('.vf-top') || e.target.closest('.vf-bottom')) return;
      if (!e.changedTouches || !e.changedTouches.length) return;
      const t = e.changedTouches[0];
      if (e.target === focusBox || focusBox.contains(e.target)) return;
      e.preventDefault();
      if (focusLocked) {
        releaseFocus();
        return;
      }
      lockFocusAt(t.clientX, t.clientY);
    }, { passive: false });
  }

  async function applyFocusAtPoint(xNorm, yNorm) {
    if (!mediaStream) return;
    const track = mediaStream.getVideoTracks()[0];
    if (!track || !track.getCapabilities) return;
    const caps = track.getCapabilities();
    const advanced = [];
    if (caps.pointsOfInterest) {
      advanced.push({ pointsOfInterest: [{ x: Math.min(1, Math.max(0, xNorm)), y: Math.min(1, Math.max(0, yNorm)) }] });
    }
    if (caps.focusMode && caps.focusMode.includes('single-shot')) {
      advanced.push({ focusMode: 'single-shot' });
    }
    if (!advanced.length) return;
    try {
      await track.applyConstraints({ advanced });
    } catch (e) {}
  }

  async function releaseFocusConstraints() {
    if (!mediaStream) return;
    const track = mediaStream.getVideoTracks()[0];
    if (!track || !track.getCapabilities) return;
    const caps = track.getCapabilities();
    if (caps.focusMode && caps.focusMode.includes('continuous')) {
      try {
        await track.applyConstraints({ advanced: [{ focusMode: 'continuous' }] });
      } catch (e) {}
    }
  }

  function isLandscapeView() {
    return window.innerWidth > window.innerHeight;
  }

  // ─── Event Config ───
  async function loadEventConfig() {
    try {
      const res = await fetch(api('event-config'));
      if (!res.ok) return;
      const cfg = await res.json();
      if (welcomeEventName) welcomeEventName.textContent = cfg.eventName || 'The Moments';
      if (welcomeEventSubtitle) welcomeEventSubtitle.textContent = cfg.eventSubtitle || 'Retreat Event';
      if (welcomeCover && cfg.coverImage) {
        welcomeCover.style.backgroundImage = `url('${url('uploads/' + cfg.coverImage)}')`;
      }
    } catch (e) {}
  }

  // ─── Gallery thumb ───
  function updateGalleryThumbnail(photos) {
    const latest = photos && photos.find((p) => p.fileType === 'photo');
    if (galleryThumb) {
      if (latest) {
        galleryThumb.classList.add('has-photo');
        galleryThumb.style.backgroundImage = `url('${url('uploads/' + latest.filename)}')`;
      } else {
        galleryThumb.classList.remove('has-photo');
        galleryThumb.style.backgroundImage = '';
      }
    }
  }

  function releaseMediaStream() {
    if (mediaRecorder && mediaRecorder.state !== 'inactive') {
      try { mediaRecorder.stop(); } catch (e) {}
    }
    mediaRecorder = null;
    isRecording = false;
    if (tlIntervalId) {
      clearInterval(tlIntervalId);
      tlIntervalId = null;
    }
    tlCapturing = false;
    if (mediaStream) {
      mediaStream.getTracks().forEach((t) => t.stop());
      mediaStream = null;
    }
    if (video) video.srcObject = null;
    focusLocked = false;
    if (focusBox) {
      focusBox.classList.add('hidden');
      focusBox.classList.remove('locked');
    }
  }

  function applyCaptionOverlay(parent, caption, yPercent) {
    if (!caption) return;
    const capEl = document.createElement('div');
    capEl.className = 'gallery-caption-overlay snap-caption-bar';
    capEl.style.top = (yPercent != null ? yPercent : 50) + '%';
    capEl.innerHTML = `<span>${escapeHtml(caption)}</span>`;
    parent.appendChild(capEl);
  }

  function getCaptionYPercent(p) {
    if (p.captionYOffset != null) return p.captionYOffset;
    return p.captionPosition === 'top' ? 25 : 75;
  }

  function wrapCanvasLines(ctx, text, maxWidth) {
    const words = String(text || '').split(/\s+/).filter(Boolean);
    if (!words.length) return [''];
    const lines = [];
    let line = '';
    for (const word of words) {
      const test = line ? line + ' ' + word : word;
      if (ctx.measureText(test).width > maxWidth && line) {
        lines.push(line);
        line = word;
      } else {
        line = test;
      }
    }
    if (line) lines.push(line);
    return lines;
  }

  function loadBlobAsImage(blob) {
    return new Promise((resolve, reject) => {
      const img = new Image();
      const objUrl = URL.createObjectURL(blob);
      img.onload = () => { URL.revokeObjectURL(objUrl); resolve(img); };
      img.onerror = () => { URL.revokeObjectURL(objUrl); reject(new Error('Image load failed')); };
      img.src = objUrl;
    });
  }

  async function compositeCaptionOnImage(blob, caption, yPercent) {
    if (!caption || !blob) return blob;
    const img = await loadBlobAsImage(blob);
    const canvas = document.createElement('canvas');
    canvas.width = img.naturalWidth || img.width;
    canvas.height = img.naturalHeight || img.height;
    const ctx = canvas.getContext('2d');
    ctx.drawImage(img, 0, 0, canvas.width, canvas.height);

    const scale = canvas.width / 390;
    const fontSize = Math.max(14, Math.round(17 * scale));
    const padY = Math.round(12 * scale);
    const padX = Math.round(18 * scale);
    const barMinH = Math.round(48 * scale);
    const lineHeight = fontSize * 1.35;

    ctx.font = `500 ${fontSize}px -apple-system, "Helvetica Neue", Arial, sans-serif`;
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';

    const maxWidth = canvas.width - padX * 2;
    const lines = wrapCanvasLines(ctx, caption, maxWidth);
    const textH = lines.length * lineHeight;
    const barH = Math.max(barMinH, textH + padY * 2);
    const centerY = ((yPercent != null ? yPercent : 50) / 100) * canvas.height;
    const barTop = Math.max(0, Math.min(canvas.height - barH, centerY - barH / 2));

    ctx.fillStyle = 'rgba(0, 0, 0, 0.72)';
    ctx.fillRect(0, barTop, canvas.width, barH);

    ctx.fillStyle = 'rgba(255, 255, 255, 0.72)';
    let textY = barTop + padY + lineHeight / 2;
    for (const line of lines) {
      ctx.fillText(line, canvas.width / 2, textY);
      textY += lineHeight;
    }

    return new Promise((resolve) => {
      canvas.toBlob((out) => resolve(out || blob), 'image/jpeg', 0.92);
    });
  }

  window.dcCompositeCaptionOnImage = compositeCaptionOnImage;

  async function getMediaDownloadBlob(p) {
    const srcUrl = url('uploads/' + p.filename);
    if (p.caption && !p.captionBurnedIn && p.fileType !== 'video') {
      const res = await fetch(srcUrl);
      const blob = await res.blob();
      return compositeCaptionOnImage(blob, p.caption, getCaptionYPercent(p));
    }
    const res = await fetch(srcUrl);
    return res.blob();
  }

  function detectLandscapeMedia(el) {
    if (!el) return false;
    if (el.videoWidth && el.videoHeight) return el.videoWidth > el.videoHeight;
    if (el.naturalWidth && el.naturalHeight) return el.naturalWidth > el.naturalHeight;
    return false;
  }

  async function refreshGalleryThumb() {
    if (!currentUser) return;
    try {
      const res = await fetch(api('gallery/' + encodeURIComponent(currentUser.participantNumber)));
      if (res.ok) {
        const photos = await res.json();
        updateGalleryThumbnail(photos);
        momentsCaptured = photos.length;
        updateMomentsDisplay();
      }
    } catch (e) {}
  }

  window.fetchUserGallery = async function () {
    if (!currentUser) return [];
    const res = await fetch(api('gallery/' + encodeURIComponent(currentUser.participantNumber)));
    if (!res.ok) throw new Error('Gallery unavailable');
    return res.json();
  };

  function updateMomentsDisplay() {
    if (!momentsCounter || !momentsCount) return;
    momentsCount.textContent = momentsCaptured;
    if (momentsCaptured > 0) {
      momentsCounter.classList.remove('hidden');
    } else {
      momentsCounter.classList.add('hidden');
    }
  }

  async function downloadMedia(p) {
    try {
      const blob = await getMediaDownloadBlob(p);
      const objUrl = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = objUrl;
      a.download = p.originalName || p.filename;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      setTimeout(() => URL.revokeObjectURL(objUrl), 1000);
    } catch (e) {
      showMicroToast('Download failed');
    }
  }

  // ─── Registration ───
  function checkSession() {
    loadEventConfig();
    const saved = localStorage.getItem('dc_user');
    if (saved) {
      try {
        const parsed = JSON.parse(saved);
        if (parsed && parsed.participantNumber && parsed.fullName && parsed.gender) {
          currentUser = parsed;
          showApp();
        } else {
          localStorage.removeItem('dc_user');
        }
      } catch (e) { localStorage.removeItem('dc_user'); }
    }
    showOrientationModal();
  }

  registerBtn.addEventListener('click', doRegister);
  participantInput.addEventListener('keydown', (e) => { if (e.key === 'Enter') doRegister(); });

  async function doRegister() {
    const num = participantInput.value.trim();
    if (!num) { registerError.textContent = 'Please enter your participant number'; return; }
    registerBtn.disabled = true;
    registerBtn.textContent = 'Checking…';
    registerError.textContent = '';
    try {
      const res = await fetch(api('validate'), {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ participantNumber: num })
      });
      const data = await res.json();
      if (!res.ok) { registerError.textContent = data.error || 'Validation failed'; return; }
      currentUser = data;
      localStorage.setItem('dc_user', JSON.stringify(data));
      showApp();
    } catch (err) {
      registerError.textContent = 'Connection error. Try again.';
    } finally {
      registerBtn.disabled = false;
      registerBtn.textContent = 'Join Event';
    }
  }

  function showApp() {
    registrationModal.classList.add('hidden');
    appEl.classList.remove('hidden');
    const displayName = truncateName(currentUser.fullName);
    userName.textContent = displayName;
    userNumber.textContent = `#${currentUser.participantNumber}`;
    const genderNorm = (currentUser.gender || '').toString().trim().toUpperCase();
    const isMale = genderNorm === 'L' || genderNorm.startsWith('LAKI');
    genderIcon.className = `gender-icon ${isMale ? 'male' : 'female'}`;
    genderIcon.innerHTML = `<img src="${url('images/' + (isMale ? 'male' : 'female') + '-icon.svg')}" alt="">`;
    initCamera();
    setupZoomGestures();
    setupFocusOverlay();
    listenForRevocation();
    refreshGalleryThumb();
    updateOrientationStyles();
    initHistoryNav();
    if (typeof initChat === 'function') initChat(currentUser);
  }

  function listenForRevocation() {
    if (typeof io === 'undefined') return;
    const socket = io({ path: BASE + 'socket.io' });
    socket.on('participant-revoked', (data) => {
      if (data.participantNumber === currentUser.participantNumber) {
        showMicroToast('Session ended — access revoked');
        setTimeout(() => { localStorage.removeItem('dc_user'); location.reload(); }, 2000);
      }
    });
    socket.on('event-reset', () => {
      showMicroToast('Event data has been reset by admin');
      momentsCaptured = 0;
      updateMomentsDisplay();
      refreshGalleryThumb();
    });
    socket.on('new-upload', (data) => {
      if (data.participantNumber === currentUser.participantNumber) {
        momentsCaptured++;
        updateMomentsDisplay();
      }
    });
  }

  logoutBtn.addEventListener('click', () => {
    if (confirm('Are you sure you want to logout?')) {
      releaseMediaStream();
      localStorage.removeItem('dc_user');
      location.reload();
    }
  });

  // ─── Settings Panel ───
  function closeSettings() {
    settingsPanel.classList.remove('visible');
    setTimeout(() => settingsPanel.classList.add('hidden'), 350);
    settingsBtn.classList.remove('active');
  }

  settingsBtn.addEventListener('click', () => {
    vibrate(20);
    settingsPanel.classList.remove('hidden');
    settingsPanel.classList.add('visible');
    settingsBtn.classList.add('active');
    pushOverlay(closeSettings);
  });
  settingsClose.addEventListener('click', () => {
    dismissOverlay(closeSettings);
  });

  function setGridEnabled(on) {
    gridEnabled = on;
    if (gridOff) gridOff.classList.toggle('active', !on);
    if (gridOn) gridOn.classList.toggle('active', on);
    gridOverlay.classList.toggle('hidden', !on);
  }

  function setContinuousMode(on) {
    continuousMode = on;
    if (shootSingle) shootSingle.classList.toggle('active', !on);
    if (shootContinuous) shootContinuous.classList.toggle('active', on);
  }

  if (gridOff) {
    gridOff.addEventListener('click', () => { vibrate(15); setGridEnabled(false); });
  }
  if (gridOn) {
    gridOn.addEventListener('click', () => { vibrate(15); setGridEnabled(true); });
  }
  if (shootSingle) {
    shootSingle.addEventListener('click', () => {
      vibrate(15);
      setContinuousMode(false);
      showMicroToast('Shooting mode: Single');
    });
  }
  if (shootContinuous) {
    shootContinuous.addEventListener('click', () => {
      vibrate(15);
      setContinuousMode(true);
      showMicroToast('Shooting mode: Continuous — photos queue to drafts');
    });
  }

  setGridEnabled(false);
  setContinuousMode(false);

  document.querySelectorAll('.timer-opt').forEach((btn) => {
    btn.addEventListener('click', () => {
      vibrate(15);
      timerSeconds = parseInt(btn.dataset.seconds, 10);
      document.querySelectorAll('.timer-opt').forEach((b) => b.classList.toggle('active', b === btn));
      showMicroToast(timerSeconds === 0 ? 'Timer off' : `${timerSeconds}s timer set`);
    });
  });

  // ─── Modes Bar (portrait + landscape sidebar) ───
  function handleModeChange(newMode, allModePills) {
    vibrate(20);
    if (newMode === currentMode) return;
    if (isRecording) stopRecording();
    if (tlCapturing) stopTimelapse();
    currentMode = newMode;
    // Sync all mode pills (portrait + landscape)
    document.querySelectorAll('.mode-pill').forEach((b) => b.classList.toggle('active', b.dataset.mode === newMode));
    captureBtn.classList.toggle('video-mode', currentMode === 'video' || currentMode === 'timelapse');
    releaseMediaStream();
    initCamera(false);
    showMicroToast(newMode.toUpperCase() + ' mode');
  }

  document.querySelectorAll('.mode-pill').forEach((btn) => {
    btn.addEventListener('click', () => handleModeChange(btn.dataset.mode));
  });

  // ─── Zoom Presets ───
  function handleZoomPreset(preset) {
    vibrate(15);
    currentZoomPreset = preset;
    // Sync all zoom preset buttons
    document.querySelectorAll('.zoom-preset-btn').forEach((b) => b.classList.toggle('active', parseFloat(b.dataset.zoom) === preset));
    setZoomPreset(preset);
  }

  document.querySelectorAll('.zoom-preset-btn').forEach((btn) => {
    btn.addEventListener('click', () => handleZoomPreset(parseFloat(btn.dataset.zoom)));
  });

  async function setZoomPreset(preset) {
    if (preset === 0.5) {
      await tryUltraWideCamera();
      updateZoomPill();
    } else {
      if (currentZoomPreset === 0.5) {
        await initCamera(false);
      }
      await setZoom(preset);
    }
  }

  // ─── Camera ───
  let ultrawideDeviceId = null;

  async function probeCameraDevices() {
    try {
      const tmp = await navigator.mediaDevices.getUserMedia({ video: { facingMode: 'environment' }, audio: false });
      tmp.getTracks().forEach((t) => t.stop());
    } catch (e) {}
    return navigator.mediaDevices.enumerateDevices();
  }

  function rankUltraWideDevices(devices) {
    const vids = devices.filter((d) => d.kind === 'videoinput');
    const scored = vids.map((d) => {
      const label = (d.label || '').toLowerCase();
      let score = 0;
      if (/front|user|selfie|facetime|depth|infrared|\bir\b|tele|telephoto|2x|3x|5x|periscope/i.test(label)) score -= 200;
      if (/ultra.?wide|ultrawide|0\.5x|0,5x|\buw\b|super.?wide/i.test(label)) score += 300;
      if (/back|rear|environment|facing back/i.test(label)) score += 10;
      return { device: d, score };
    });
    scored.sort((a, b) => b.score - a.score);
    return scored.map((s) => s.device);
  }

  function isFrontCameraLabel(label) {
    return /front|user|selfie|facetime|depth|infrared|\bir\b/i.test((label || '').toLowerCase());
  }

  function isUltraWideLabel(label) {
    return /ultra.?wide|ultrawide|0\.5x|0,5x|\buw\b|super.?wide/i.test((label || '').toLowerCase());
  }

  async function applyWidestNativeZoom(track) {
    const caps = track.getCapabilities ? track.getCapabilities() : {};
    if (!caps.zoom || caps.zoom.min >= 1) return track.getSettings?.()?.zoom ?? 1;
    try {
      await track.applyConstraints({ advanced: [{ zoom: caps.zoom.min }] });
      return track.getSettings?.()?.zoom ?? caps.zoom.min;
    } catch (e) {
      return caps.zoom.min;
    }
  }

  async function probeCameraWideFactor(deviceId) {
    let stream = null;
    try {
      stream = await navigator.mediaDevices.getUserMedia({
        video: { deviceId: { exact: deviceId }, width: { ideal: 1920 }, height: { ideal: 1080 } },
        audio: false
      });
      const track = stream.getVideoTracks()[0];
      const wideFactor = await applyWidestNativeZoom(track);
      return { wideFactor, label: track.label || '' };
    } finally {
      if (stream) stream.getTracks().forEach((t) => t.stop());
    }
  }

  async function openBackCameraStream(deviceId) {
    const video = deviceId
      ? { deviceId: { exact: deviceId }, width: { ideal: 1920 }, height: { ideal: 1080 } }
      : { facingMode: { ideal: 'environment' }, width: { ideal: 1920 }, height: { ideal: 1080 } };
    return navigator.mediaDevices.getUserMedia({ video, audio: currentMode === 'video' });
  }

  async function tryUltraWideCamera() {
    try {
      releaseMediaStream();
      nativeZoomActive = false;
      currentFacingMode = 'environment';
      ultrawideDeviceId = null;

      let best = null;

      const unifiedAttempts = [
        { facingMode: { exact: 'environment' }, width: { ideal: 1920 }, height: { ideal: 1080 }, zoom: { ideal: 0.5, min: 0.5, max: 1 } },
        { facingMode: 'environment', width: { ideal: 1920 }, height: { ideal: 1080 }, zoom: { ideal: 0.5 } },
        { facingMode: { ideal: 'environment' }, width: { ideal: 1920 }, height: { ideal: 1080 }, advanced: [{ zoom: 0.5 }] }
      ];

      for (const videoConstraint of unifiedAttempts) {
        let stream = null;
        try {
          stream = await navigator.mediaDevices.getUserMedia({ video: videoConstraint, audio: currentMode === 'video' });
          const track = stream.getVideoTracks()[0];
          const wideFactor = await applyWidestNativeZoom(track);
          const label = track.label || '';
          const score = (isUltraWideLabel(label) ? 1000 : 0) + (1 - wideFactor) * 100;
          if (!best || score > best.score) {
            if (best?.stream) best.stream.getTracks().forEach((t) => t.stop());
            best = { stream, track, deviceId: track.getSettings?.()?.deviceId, wideFactor, score, label };
          } else {
            stream.getTracks().forEach((t) => t.stop());
          }
        } catch (e) {
          if (stream) stream.getTracks().forEach((t) => t.stop());
        }
      }

      const devices = await probeCameraDevices();
      const ranked = rankUltraWideDevices(devices);
      const seen = new Set();

      for (const dev of ranked) {
        if (!dev.deviceId || seen.has(dev.deviceId) || isFrontCameraLabel(dev.label)) continue;
        seen.add(dev.deviceId);
        try {
          const probe = await probeCameraWideFactor(dev.deviceId);
          const label = probe.label || dev.label || '';
          const score = (isUltraWideLabel(label) ? 1000 : 0) + (1 - probe.wideFactor) * 100;
          if (!best || score > best.score) {
            if (best?.stream) best.stream.getTracks().forEach((t) => t.stop());
            const stream = await openBackCameraStream(dev.deviceId);
            const track = stream.getVideoTracks()[0];
            const wideFactor = await applyWidestNativeZoom(track);
            best = {
              stream,
              track,
              deviceId: dev.deviceId,
              wideFactor,
              score: (isUltraWideLabel(label) ? 1000 : 0) + (1 - wideFactor) * 100,
              label
            };
          }
        } catch (e) {}
      }

      const ok = best && (isUltraWideLabel(best.label) || best.wideFactor <= 0.85);
      if (ok) {
        mediaStream = best.stream;
        video.srcObject = best.stream;
        ultrawideDeviceId = best.deviceId || best.track.getSettings?.()?.deviceId || null;
        nativeZoomActive = best.wideFactor < 1;
        applyMirror();
        applyFlash();
        zoomLevel = 0.5;
        zoomLayer.style.transform = 'scale(1)';
        currentZoomPreset = 0.5;
        updateZoomPill();
        return;
      }

      if (best?.stream) best.stream.getTracks().forEach((t) => t.stop());
      await initCamera(false);
      currentZoomPreset = 1;
      document.querySelectorAll('.zoom-preset-btn').forEach((b) => b.classList.toggle('active', parseFloat(b.dataset.zoom) === 1));
      await setZoom(1);
      showMicroToast('Ultra-wide lens not available — using main camera');
    } catch (err) {
      console.error('Ultra-wide error:', err);
      await initCamera(false);
    }
  }

  async function initCamera(requestUltraWide) {
    try {
      if (mediaStream) {
        mediaStream.getTracks().forEach((t) => t.stop());
        mediaStream = null;
      }
      if (video && video.srcObject) video.srcObject = null;
      const constraints = {
        video: {
          facingMode: currentFacingMode,
          width: { ideal: 1920 },
          height: { ideal: 1080 }
        },
        audio: currentMode === 'video'
      };
      mediaStream = await navigator.mediaDevices.getUserMedia(constraints);
      video.srcObject = mediaStream;
      applyMirror();
      applyFlash();
      // Reset CSS zoom when reinitializing — prevents stale scale
      zoomLayer.style.transform = 'scale(1)';
      zoomLevel = 1;
      nativeZoomActive = false;
    } catch (err) {
      console.error('Camera error:', err);
    }
  }

  function applyMirror() {
    const auto = currentFacingMode === 'user';
    const on = mirrorOverride === null ? auto : mirrorOverride;
    video.classList.toggle('mirrored', on);
  }

  async function applyFlash() {
    if (!mediaStream) return;
    const track = mediaStream.getVideoTracks()[0];
    if (!track) return;
    const torchOn = flashMode === 'on';
    try { await track.applyConstraints({ advanced: [{ torch: torchOn }] }); } catch (e) {}
  }

  flashBtn.addEventListener('click', () => {
    vibrate(20);
    const modes = ['off', 'on', 'auto'];
    flashMode = modes[(modes.indexOf(flashMode) + 1) % modes.length];
    flashBtn.dataset.mode = flashMode;
    flashBtn.querySelector('.flash-off').classList.toggle('hidden', flashMode === 'on');
    flashBtn.querySelector('.flash-on').classList.toggle('hidden', flashMode !== 'on');
    if (flashMode === 'on' || flashMode === 'off') applyFlash();
  });

  rotateBtn.addEventListener('click', () => {
    vibrate(30);
    currentFacingMode = currentFacingMode === 'environment' ? 'user' : 'environment';
    mirrorOverride = null;
    currentZoomPreset = 1;
    document.querySelectorAll('.zoom-preset-btn').forEach((b) => b.classList.toggle('active', parseFloat(b.dataset.zoom) === 1));
    releaseMediaStream();
    initCamera(false);
  });

  async function applyNativeZoom(level) {
    if (!mediaStream || currentZoomPreset === 0.5) return false;
    const track = mediaStream.getVideoTracks()[0];
    if (!track || !track.getCapabilities) return false;
    const caps = track.getCapabilities();
    if (!caps.zoom) return false;
    const z = Math.min(Math.max(level, caps.zoom.min || 1), Math.min(caps.zoom.max || 10, 10));
    try {
      await track.applyConstraints({ advanced: [{ zoom: z }] });
      zoomLevel = z;
      nativeZoomActive = true;
      zoomLayer.style.transform = 'scale(1)';
      return true;
    } catch (e) {
      return false;
    }
  }

  function updateZoomPill() {
    const zoomPill = document.getElementById('zoom-indicator');
    if (!zoomPill) return;
    const displayLevel = currentZoomPreset === 0.5 ? 0.5 : zoomLevel;
    if (Math.abs(displayLevel - 1) > 0.05) {
      zoomPill.textContent = displayLevel.toFixed(1) + '×';
      zoomPill.classList.remove('hidden');
    } else {
      zoomPill.classList.add('hidden');
    }
  }

  async function setZoom(level) {
    if (currentZoomPreset === 0.5 && level >= 1) {
      currentZoomPreset = 1;
      document.querySelectorAll('.zoom-preset-btn').forEach((b) => {
        b.classList.toggle('active', parseFloat(b.dataset.zoom) === 1);
      });
      await initCamera(false);
    }
    zoomLevel = Math.min(Math.max(level, 1.0), 10);
    const nativeOk = await applyNativeZoom(zoomLevel);
    if (!nativeOk) {
      nativeZoomActive = false;
      zoomLayer.style.transform = `scale(${zoomLevel})`;
    }
    updateZoomPill();
  }

  function resetZoom() {
    setZoom(1);
  }

  const zoomPillBtn = document.getElementById('zoom-indicator');
  if (zoomPillBtn) zoomPillBtn.addEventListener('click', () => { vibrate(15); resetZoom(); });

  function setupZoomGestures() {
    viewfinder.addEventListener('touchstart', onTouchStart, { passive: false });
    viewfinder.addEventListener('touchmove', onTouchMove, { passive: false });
    viewfinder.addEventListener('touchend', onTouchEnd);
    viewfinder.addEventListener('dblclick', (e) => {
      e.preventDefault(); vibrate(20);
      setZoom(zoomLevel > 1.1 ? 1 : 2);
    });
  }

  function touchDist(touches) {
    const dx = touches[0].clientX - touches[1].clientX;
    const dy = touches[0].clientY - touches[1].clientY;
    return Math.hypot(dx, dy);
  }

  function onTouchStart(e) {
    if (e.touches.length === 2) {
      e.preventDefault();
      pinchStartDist = touchDist(e.touches);
      pinchStartZoom = zoomLevel;
    } else if (e.touches.length === 1) {
      const now = Date.now();
      if (now - lastTapTime < 300) {
        e.preventDefault();
        setZoom(zoomLevel > 1.1 ? 1 : 2);
        lastTapTime = 0;
      } else { lastTapTime = now; }
    }
  }

  function onTouchMove(e) {
    if (e.touches.length === 2) {
      e.preventDefault();
      const dist = touchDist(e.touches);
      const rawZoom = pinchStartZoom * (dist / pinchStartDist);
      setZoom(rawZoom); // setZoom already clamps to min 1.0
    }
  }

  function onTouchEnd() { pinchStartDist = 0; }

  // ─── Capture (timer-aware) ───
  function handleCaptureTrigger() {
    if (currentMode === 'timelapse') {
      tlCapturing ? stopTimelapse() : startTimelapse();
      return;
    }
    if (currentMode === 'video') {
      isRecording ? stopRecording() : startRecordingWithTimer();
      return;
    }
    if (timerSeconds > 0 && !timerActive) {
      startTimerThenCapture();
    } else if (!timerActive) {
      takePhoto();
    }
  }

  captureBtn.addEventListener('click', handleCaptureTrigger);

  // Long-press for video
  captureBtn.addEventListener('touchstart', () => {
    if (currentMode !== 'photo') return;
    longPressTimer = setTimeout(() => {
      document.querySelectorAll('.mode-pill').forEach((b) => b.classList.toggle('active', b.dataset.mode === 'video'));
      currentMode = 'video';
      captureBtn.classList.add('video-mode');
      releaseMediaStream();
      initCamera(false).then(() => startRecording());
    }, 800);
  }, { passive: true });
  captureBtn.addEventListener('touchend', () => clearTimeout(longPressTimer));
  captureBtn.addEventListener('touchcancel', () => clearTimeout(longPressTimer));

  // ─── Self Timer ───
  function startTimerThenCapture() {
    timerActive = true;
    let count = timerSeconds;
    timerCountdownEl.textContent = count;
    timerCountdownEl.classList.remove('hidden');
    vibrate(30);

    timerCountdownId = setInterval(() => {
      count--;
      if (count > 0) {
        timerCountdownEl.textContent = count;
        playTimerBeep(false);
        vibrate(20);
        timerCountdownEl.style.animation = 'none';
        timerCountdownEl.offsetHeight;
        timerCountdownEl.style.animation = '';
      } else {
        clearInterval(timerCountdownId);
        timerCountdownEl.classList.add('hidden');
        timerActive = false;
        playTimerBeep(true);
        takePhoto();
      }
    }, 1000);
  }

  function startRecordingWithTimer() {
    if (timerSeconds > 0 && !timerActive) {
      timerActive = true;
      let count = timerSeconds;
      timerCountdownEl.textContent = count;
      timerCountdownEl.classList.remove('hidden');
      timerCountdownId = setInterval(() => {
        count--;
        if (count > 0) {
          timerCountdownEl.textContent = count;
          playTimerBeep(false);
          timerCountdownEl.style.animation = 'none';
          timerCountdownEl.offsetHeight;
          timerCountdownEl.style.animation = '';
        } else {
          clearInterval(timerCountdownId);
          timerCountdownEl.classList.add('hidden');
          timerActive = false;
          startRecording();
        }
      }, 1000);
    } else if (!timerActive) {
      startRecording();
    }
  }

  function getCssZoomScale() {
    const m = (zoomLayer.style.transform || '').match(/scale\(([\d.]+)\)/);
    return m ? parseFloat(m[1]) : zoomLevel;
  }

  function drawVideoFrame(ctx, videoEl) {
    const vw = videoEl.videoWidth;
    const vh = videoEl.videoHeight;
    const track = mediaStream?.getVideoTracks()[0];
    const settings = track?.getSettings?.() || {};
    const nativeZ = settings.zoom || 1;
    const cssScale = getCssZoomScale();

    if (nativeZoomActive && nativeZ > 1.01) {
      ctx.drawImage(videoEl, 0, 0, vw, vh);
      return;
    }
    if (cssScale <= 1.01) {
      ctx.drawImage(videoEl, 0, 0, vw, vh);
      return;
    }
    const cropW = vw / cssScale;
    const cropH = vh / cssScale;
    const sx = (vw - cropW) / 2;
    const sy = (vh - cropH) / 2;
    ctx.drawImage(videoEl, sx, sy, cropW, cropH, 0, 0, vw, vh);
  }

  // ─── Take Photo ───
  async function takePhoto() {
    if (isCapturing) return;
    isCapturing = true;
    const landscape = isLandscapeView();

    try {
      if (!video.videoWidth || !video.videoHeight) {
        await new Promise((resolve) => {
          if (video.videoWidth) return resolve();
          const onReady = () => { video.removeEventListener('loadeddata', onReady); resolve(); };
          video.addEventListener('loadeddata', onReady);
          setTimeout(resolve, landscape ? 50 : 120);
        });
      }

      const w = video.videoWidth || 1280;
      const h = video.videoHeight || 720;

      vibrate(50);
      playShutterSound();

      await new Promise((r) => requestAnimationFrame(r));

      canvas.width = w;
      canvas.height = h;
      const ctx = canvas.getContext('2d', { alpha: false, desynchronized: landscape });
      if (video.classList.contains('mirrored')) { ctx.translate(canvas.width, 0); ctx.scale(-1, 1); }
      drawVideoFrame(ctx, video);

      if (flashMode === 'on' || flashMode === 'auto') applyFlash().catch(() => {});

      canvas.toBlob((blob) => {
        isCapturing = false;
        if (!blob) {
          showMicroToast('Capture failed — try again');
          return;
        }
        if (continuousMode) {
          addToDraftQueue(blob, 'photo.jpg', 'image/jpeg');
        } else {
          showReviewScreen(blob, 'photo.jpg', 'image/jpeg', false);
        }
        if (flashMode === 'auto') {
          setTimeout(() => {
            flashMode = 'off';
            flashBtn.dataset.mode = 'off';
            flashBtn.querySelector('.flash-off').classList.remove('hidden');
            flashBtn.querySelector('.flash-on').classList.add('hidden');
            applyFlash();
          }, 300);
        }
      }, 'image/jpeg', landscape ? 0.86 : 0.92);
    } catch (err) {
      isCapturing = false;
      console.error('Photo capture error:', err);
      showMicroToast('Capture failed — try again');
    }
  }

  // ─── Video Recording ───
  function startRecording() {
    if (!mediaStream) return;
    vibrate([50, 50, 50]);
    playBeepSound();
    recordedChunks = [];
    const options = { mimeType: 'video/webm;codecs=vp8,opus' };
    try { mediaRecorder = new MediaRecorder(mediaStream, options); }
    catch (e) {
      try { mediaRecorder = new MediaRecorder(mediaStream, { mimeType: 'video/webm' }); }
      catch (e2) { mediaRecorder = new MediaRecorder(mediaStream); }
    }
    mediaRecorder.ondataavailable = (e) => { if (e.data && e.data.size > 0) recordedChunks.push(e.data); };
    mediaRecorder.onstop = () => {
      const blob = new Blob(recordedChunks, { type: mediaRecorder.mimeType || 'video/webm' });
      recordedChunks = [];
      if (continuousMode) addToDraftQueue(blob, 'video.webm', blob.type);
      else showReviewScreen(blob, 'video.webm', blob.type, true);
    };
    mediaRecorder.start(100);
    isRecording = true;
    captureBtn.classList.add('recording');
    recordingIndicator.classList.remove('hidden');
    recStart = Date.now();
    recTimer.textContent = '00:00';
    recTimerId = setInterval(() => {
      const s = Math.floor((Date.now() - recStart) / 1000);
      recTimer.textContent = `${String(Math.floor(s/60)).padStart(2,'0')}:${String(s%60).padStart(2,'0')}`;
    }, 500);
  }

  function stopRecording() {
    if (mediaRecorder && mediaRecorder.state !== 'inactive') mediaRecorder.stop();
    isRecording = false;
    captureBtn.classList.remove('recording');
    recordingIndicator.classList.add('hidden');
    if (recTimerId) { clearInterval(recTimerId); recTimerId = null; }
    vibrate(100);
  }

  // ─── Timelapse (record → preview with speed slider → upload) ───
  function startTimelapse() {
    if (!mediaStream || tlCapturing) return;
    tlCapturing = true;
    tlRecordedChunks = [];
    tlRecStart = Date.now();
    captureBtn.classList.add('recording');
    tlIndicator.classList.remove('hidden');
    if (tlFrameCountEl) tlFrameCountEl.textContent = 'REC';
    vibrate([50, 50, 50]);
    showMicroToast('Timelapse recording — tap stop when done');

    const options = { mimeType: 'video/webm;codecs=vp8,opus' };
    try { tlMediaRecorder = new MediaRecorder(mediaStream, options); }
    catch (e) {
      try { tlMediaRecorder = new MediaRecorder(mediaStream, { mimeType: 'video/webm' }); }
      catch (e2) { tlMediaRecorder = new MediaRecorder(mediaStream); }
    }
    tlMediaRecorder.ondataavailable = (e) => {
      if (e.data && e.data.size > 0) tlRecordedChunks.push(e.data);
    };
    tlMediaRecorder.onstop = () => { finishTimelapseRecording(); };
    tlMediaRecorder.start(250);
  }

  function finishTimelapseRecording() {
    const blob = new Blob(tlRecordedChunks, { type: tlMediaRecorder?.mimeType || 'video/webm' });
    tlRecordedChunks = [];
    tlMediaRecorder = null;

    if (!blob || blob.size < 1000) {
      showMicroToast('Timelapse too short — record longer');
      return;
    }
    showTimelapseReviewScreen(blob);
  }

  function clearTimelapseProcessed() {
    if (tlProcessedObjUrl) URL.revokeObjectURL(tlProcessedObjUrl);
    tlProcessedBlob = null;
    tlProcessedObjUrl = null;
  }

  function showTimelapseReviewScreen(blob) {
    clearTimelapseProcessed();
    if (tlProcessAbort) tlProcessAbort.abort();
    tlProcessGen++;

    pendingCapture = {
      blob,
      filename: 'timelapse-source.webm',
      mimetype: blob.type || 'video/webm',
      isVideo: true,
      isTimelapse: true,
      timelapseSpeed: 15
    };
    reviewCaptionInput.value = '';
    snapCaptionText.textContent = '';
    snapCaptionBar.style.display = 'none';
    snapTapHint.classList.add('hidden');
    if (timelapseSpeedPanel) timelapseSpeedPanel.classList.remove('hidden');
    if (reviewControls) reviewControls.classList.add('timelapse-mode');
    if (tlSpeedSlider) tlSpeedSlider.value = '15';
    if (tlSpeedInput) tlSpeedInput.value = '15';
    if (tlSpeedValue) tlSpeedValue.textContent = '15x';
    if (tlProcessingOverlay) tlProcessingOverlay.classList.add('hidden');

    reviewMedia.innerHTML = '';
    if (reviewObjUrl) URL.revokeObjectURL(reviewObjUrl);
    reviewObjUrl = URL.createObjectURL(blob);
    const v = document.createElement('video');
    v.src = reviewObjUrl;
    v.controls = true;
    v.playsInline = true;
    v.muted = true;
    v.loop = true;
    reviewMedia.appendChild(v);
    v.addEventListener('loadedmetadata', () => {
      reviewMedia.classList.toggle('landscape-media', detectLandscapeMedia(v));
    });

    reviewScreen.classList.remove('hidden');
    appEl.classList.add('hidden');
    pushOverlay(() => closeReviewScreen());
  }

  async function processTimelapseSpeed(speed) {
    if (!pendingCapture || !pendingCapture.isTimelapse) return;
    const gen = ++tlProcessGen;
    if (tlProcessAbort) tlProcessAbort.abort();
    tlProcessAbort = new AbortController();

    if (tlProcessingOverlay) tlProcessingOverlay.classList.remove('hidden');
    const vid = reviewMedia.querySelector('video');
    if (vid) vid.style.visibility = 'hidden';

    try {
      const formData = new FormData();
      formData.append('video', pendingCapture.blob, 'timelapse-source.webm');
      formData.append('speed', String(speed));
      const res = await fetch(api('timelapse-speedup'), {
        method: 'POST',
        body: formData,
        signal: tlProcessAbort.signal
      });
      if (gen !== tlProcessGen) return;
      if (!res.ok) {
        let msg = 'Timelapse speed-up failed';
        try { const d = await res.json(); msg = d.error || d.detail || msg; } catch (e) {}
        throw new Error(msg);
      }
      const outBlob = await res.blob();
      if (!outBlob || outBlob.size < 500) throw new Error('Empty timelapse output');

      clearTimelapseProcessed();
      tlProcessedBlob = outBlob;
      tlProcessedObjUrl = URL.createObjectURL(outBlob);
      pendingCapture.timelapseSpeed = speed;
      pendingCapture.processedBlob = outBlob;

      reviewMedia.innerHTML = '';
      const pv = document.createElement('video');
      pv.src = tlProcessedObjUrl;
      pv.controls = true;
      pv.playsInline = true;
      pv.autoplay = true;
      pv.muted = true;
      pv.loop = true;
      reviewMedia.appendChild(pv);
      pv.addEventListener('loadedmetadata', () => {
        reviewMedia.classList.toggle('landscape-media', detectLandscapeMedia(pv));
      });
    } catch (e) {
      if (e.name === 'AbortError') return;
      console.error('[TIMELAPSE ERROR]: ', e);
      showMicroToast('Processing failed: ' + (e.message || 'try again'));
      const vid2 = reviewMedia.querySelector('video');
      if (vid2) vid2.style.visibility = '';
    } finally {
      if (gen === tlProcessGen && tlProcessingOverlay) tlProcessingOverlay.classList.add('hidden');
    }
  }

  async function uploadTimelapseWithSpeed(sourceBlob, speed) {
    const blob = tlProcessedBlob || sourceBlob;
    if (tlProcessedBlob && pendingCapture?.timelapseSpeed === speed) {
      const ext = (blob.type || '').includes('mp4') ? 'mp4' : 'webm';
      await uploadMedia(blob, 'timelapse.' + ext, blob.type || 'video/mp4', '', 'bottom', 50);
      return;
    }
    showMicroToast(`Processing ${speed}x…`);
    const formData = new FormData();
    formData.append('video', sourceBlob, 'timelapse-source.webm');
    formData.append('speed', String(speed));
    const controller = new AbortController();
    const timeoutId = setTimeout(() => controller.abort(), 180000);
    const res = await fetch(api('timelapse-speedup'), { method: 'POST', body: formData, signal: controller.signal });
    clearTimeout(timeoutId);
    if (!res.ok) {
      let msg = 'Timelapse speed-up failed';
      try { const d = await res.json(); msg = d.error || d.detail || msg; } catch (e) {}
      throw new Error(msg);
    }
    const outBlob = await res.blob();
    if (!outBlob || outBlob.size < 500) throw new Error('Empty timelapse output');
    const ext = (outBlob.type || '').includes('mp4') ? 'mp4' : 'webm';
    await uploadMedia(outBlob, 'timelapse.' + ext, outBlob.type || 'video/mp4', '', 'bottom', 50);
  }

  function stopTimelapse() {
    tlCapturing = false;
    captureBtn.classList.remove('recording');
    tlIndicator.classList.add('hidden');
    vibrate(100);
    if (tlMediaRecorder && tlMediaRecorder.state !== 'inactive') {
      try { tlMediaRecorder.stop(); } catch (e) {
        console.error('[TIMELAPSE ERROR]: stop recorder —', e);
        finishTimelapseRecording();
      }
    } else {
      showMicroToast('No timelapse recording to process');
    }
  }

  // ─── Draft Queue ───
  function addToDraftQueue(blob, filename, mimetype) {
    const objUrl = URL.createObjectURL(blob);
    draftQueue.push({ blob, filename, mimetype, objUrl, caption: '', snapBarY: 50 });
    updateDraftBadge();
    vibrate(30);
    playShutterSound();
    showMicroToast(`Draft #${draftQueue.length} queued`);
  }

  function updateDraftBadge() {
    if (draftQueue.length > 0) {
      draftCount.textContent = draftQueue.length;
      draftBadge.classList.remove('hidden');
    } else {
      draftBadge.classList.add('hidden');
    }
  }

  draftBadge.addEventListener('click', openDraftPanel);
  draftBadge.addEventListener('keydown', (e) => { if (e.key === 'Enter' || e.key === ' ') openDraftPanel(); });

  draftPanelClose.addEventListener('click', () => dismissOverlay(closeDraftPanel));

  draftDiscardAll.addEventListener('click', () => {
    if (!confirm('Discard all drafts?')) return;
    draftQueue.forEach(d => URL.revokeObjectURL(d.objUrl));
    draftQueue = [];
    updateDraftBadge();
    draftReviewPanel.classList.add('hidden');
    showMicroToast('All drafts discarded');
  });

  draftUploadAll.addEventListener('click', async () => {
    if (!draftQueue.length) return;
    draftReviewPanel.classList.add('hidden');
    const items = [...draftQueue];
    draftQueue = [];
    updateDraftBadge();
    showMicroToast(`Uploading ${items.length} items…`);
    for (const item of items) {
      const yPos = item.snapBarY != null ? item.snapBarY : 50;
      await uploadMedia(item.blob, item.filename, item.mimetype, item.caption, yPos < 50 ? 'top' : 'bottom', yPos);
      URL.revokeObjectURL(item.objUrl);
    }
    refreshGalleryThumb();
  });

  draftUploadCurrent.addEventListener('click', async () => {
    if (!draftQueue.length) return;
    const item = draftQueue[draftViewIndex];
    if (!item) return;
    // Save current caption
    item.caption = draftCaptionInput.value.trim();
    draftReviewPanel.classList.add('hidden');
    await uploadMedia(item.blob, item.filename, item.mimetype, item.caption,
      (item.snapBarY != null && item.snapBarY < 50) ? 'top' : 'bottom',
      item.snapBarY != null ? item.snapBarY : 50);
    URL.revokeObjectURL(item.objUrl);
    draftQueue.splice(draftViewIndex, 1);
    updateDraftBadge();
    if (draftQueue.length === 0) {
      refreshGalleryThumb();
    } else {
      draftViewIndex = Math.min(draftViewIndex, draftQueue.length - 1);
      openDraftPanel();
    }
    refreshGalleryThumb();
  });

  draftDeleteCurrent.addEventListener('click', () => {
    if (!draftQueue.length) return;
    const item = draftQueue[draftViewIndex];
    if (!item) return;
    URL.revokeObjectURL(item.objUrl);
    draftQueue.splice(draftViewIndex, 1);
    updateDraftBadge();
    if (draftQueue.length === 0) {
      draftReviewPanel.classList.add('hidden');
      showMicroToast('Draft deleted');
    } else {
      draftViewIndex = Math.min(draftViewIndex, draftQueue.length - 1);
      renderDraftViewer();
    }
  });

  draftPrev.addEventListener('click', () => {
    if (draftViewIndex > 0) {
      saveDraftCaption();
      draftViewIndex--;
      renderDraftViewer();
    }
  });

  draftNext.addEventListener('click', () => {
    if (draftViewIndex < draftQueue.length - 1) {
      saveDraftCaption();
      draftViewIndex++;
      renderDraftViewer();
    }
  });

  draftCaptionInput.addEventListener('input', () => {
    const text = draftCaptionInput.value.trim();
    draftSnapText.textContent = text;
    draftSnapBar.style.display = text ? 'flex' : 'none';
    draftViewerHint.classList.toggle('hidden', !!text);
    if (draftQueue[draftViewIndex]) draftQueue[draftViewIndex].caption = text;
  });

  function saveDraftCaption() {
    if (draftQueue[draftViewIndex]) {
      draftQueue[draftViewIndex].caption = draftCaptionInput.value.trim();
      const barTopPct = parseFloat(draftSnapBar.style.top) || 50;
      draftQueue[draftViewIndex].snapBarY = barTopPct;
    }
  }

  function closeDraftPanel() {
    draftReviewPanel.classList.add('hidden');
  }

  function openDraftPanel() {
    if (!draftQueue.length) return;
    draftViewIndex = Math.min(draftViewIndex, draftQueue.length - 1);
    draftPanelCount.textContent = `${draftQueue.length} photo${draftQueue.length !== 1 ? 's' : ''}`;
    renderDraftViewer();
    draftReviewPanel.classList.remove('hidden');
    pushOverlay(closeDraftPanel);
  }

  function renderDraftViewer() {
    const item = draftQueue[draftViewIndex];
    if (!item) return;

    draftPanelCount.textContent = `${draftQueue.length} photo${draftQueue.length !== 1 ? 's' : ''}`;
    draftItemCounter.textContent = `${draftViewIndex + 1} / ${draftQueue.length}`;

    // Render media
    draftViewerMedia.innerHTML = '';
    const isVideo = item.mimetype && item.mimetype.startsWith('video');
    if (isVideo) {
      const v = document.createElement('video');
      v.src = item.objUrl; v.controls = true; v.autoplay = true;
      v.muted = true; v.playsInline = true; v.loop = true;
      draftViewerMedia.appendChild(v);
      v.addEventListener('loadedmetadata', () => {
        draftViewerMedia.classList.toggle('landscape-media', detectLandscapeMedia(v));
      });
    } else {
      const img = document.createElement('img');
      img.src = item.objUrl;
      img.decoding = 'async';
      img.addEventListener('load', () => {
        draftViewerMedia.classList.toggle('landscape-media', detectLandscapeMedia(img));
      });
      draftViewerMedia.appendChild(img);
    }

    // Caption bar
    const caption = item.caption || '';
    draftCaptionInput.value = caption;
    draftSnapText.textContent = caption;
    const barY = item.snapBarY !== undefined ? item.snapBarY : 50;
    draftSnapBar.style.top = barY + '%';
    draftSnapBar.style.display = caption ? 'flex' : 'none';
    draftViewerHint.classList.toggle('hidden', !!caption);

    // Nav buttons
    draftPrev.style.display = draftViewIndex > 0 ? 'flex' : 'none';
    draftNext.style.display = draftViewIndex < draftQueue.length - 1 ? 'flex' : 'none';
  }

  // ─── Draft snap bar drag ───
  setupSnapBarDrag(draftSnapBar, {
    getY: () => parseFloat(draftSnapBar.style.top) || 50,
    setY: (pct) => {
      draftSnapBar.style.top = pct + '%';
      if (draftQueue[draftViewIndex]) draftQueue[draftViewIndex].snapBarY = pct;
    },
    getContainer: () => draftSnapBar.parentElement
  });

  function closeReviewScreen() {
    if (tlProcessTimer) clearTimeout(tlProcessTimer);
    if (tlProcessAbort) tlProcessAbort.abort();
    tlProcessGen++;
    pendingCapture = null;
    reviewMedia.innerHTML = '';
    snapCaptionBar.style.display = 'none';
    if (reviewObjUrl) { URL.revokeObjectURL(reviewObjUrl); reviewObjUrl = null; }
    clearTimelapseProcessed();
    if (timelapseSpeedPanel) timelapseSpeedPanel.classList.add('hidden');
    if (reviewControls) reviewControls.classList.remove('timelapse-mode');
    if (tlProcessingOverlay) tlProcessingOverlay.classList.add('hidden');
    reviewScreen.classList.add('hidden');
    appEl.classList.remove('hidden');
  }

  // ─── Review Screen ───
  function showReviewScreen(blob, filename, mimetype, isVideo) {
    pendingCapture = { blob, filename, mimetype, isVideo };
    reviewCaptionInput.value = '';
    snapCaptionText.textContent = '';
    snapCaptionBar.style.display = 'none';
    snapBarY = 50;
    snapCaptionBar.style.top = '50%';
    snapTapHint.classList.remove('hidden');
    if (timelapseSpeedPanel) timelapseSpeedPanel.classList.add('hidden');
    if (reviewControls) reviewControls.classList.remove('timelapse-mode');

    reviewMedia.innerHTML = '';
    if (reviewObjUrl) URL.revokeObjectURL(reviewObjUrl);
    reviewObjUrl = URL.createObjectURL(blob);
    if (isVideo) {
      const v = document.createElement('video');
      v.src = reviewObjUrl; v.controls = true; v.autoplay = true;
      v.muted = true; v.playsInline = true; v.loop = true;
      reviewMedia.appendChild(v);
      v.addEventListener('loadedmetadata', () => {
        reviewMedia.classList.toggle('landscape-media', detectLandscapeMedia(v));
      });
    } else {
      const img = document.createElement('img');
      img.src = reviewObjUrl;
      img.decoding = 'async';
      img.addEventListener('load', () => {
        reviewMedia.classList.toggle('landscape-media', detectLandscapeMedia(img));
      });
      reviewMedia.appendChild(img);
    }

    reviewScreen.classList.remove('hidden');
    appEl.classList.add('hidden');
    pushOverlay(() => closeReviewScreen());
  }

  // ─── Snap Caption Bar (full-width, vertical drag only) ───
  reviewCaptionInput.addEventListener('input', () => {
    const text = reviewCaptionInput.value.trim();
    if (text) {
      snapCaptionText.textContent = text;
      snapCaptionBar.style.display = 'flex';
      snapTapHint.classList.add('hidden');
    } else {
      snapCaptionText.textContent = '';
      snapCaptionBar.style.display = 'none';
      snapTapHint.classList.remove('hidden');
    }
  });

  // Generic vertical drag setup for full-width caption bars
  function setupSnapBarDrag(barEl, opts) {
    let dragging = false;
    let startClientY = 0;
    let startTopPct = 50;

    function getTopPercent(clientY, deltaY) {
      const container = opts.getContainer();
      const rect = container.getBoundingClientRect();
      const newTopPx = (startTopPct / 100) * rect.height + deltaY;
      const pct = (newTopPx / rect.height) * 100;
      return Math.max(3, Math.min(97, pct));
    }

    barEl.addEventListener('mousedown', (e) => {
      dragging = true;
      startClientY = e.clientY;
      startTopPct = opts.getY();
      e.preventDefault();
    });

    barEl.addEventListener('touchstart', (e) => {
      if (e.touches.length !== 1) return;
      dragging = true;
      startClientY = e.touches[0].clientY;
      startTopPct = opts.getY();
      e.preventDefault();
    }, { passive: false });

    document.addEventListener('mousemove', (e) => {
      if (!dragging) return;
      const pct = getTopPercent(e.clientY, e.clientY - startClientY);
      opts.setY(pct);
    });

    document.addEventListener('touchmove', (e) => {
      if (!dragging) return;
      const pct = getTopPercent(e.touches[0].clientY, e.touches[0].clientY - startClientY);
      opts.setY(pct);
    }, { passive: false });

    document.addEventListener('mouseup', () => { dragging = false; });
    document.addEventListener('touchend', () => { dragging = false; });
  }

  setupSnapBarDrag(snapCaptionBar, {
    getY: () => snapBarY,
    setY: (pct) => { snapBarY = pct; snapCaptionBar.style.top = pct + '%'; },
    getContainer: () => snapCaptionBar.parentElement
  });

  function clampTimelapseSpeed(val) {
    return Math.min(50, Math.max(1, Math.round(val) || 1));
  }

  function syncTimelapseSpeedUI(speed) {
    const s = clampTimelapseSpeed(speed);
    if (tlSpeedSlider) tlSpeedSlider.value = String(s);
    if (tlSpeedInput) tlSpeedInput.value = String(s);
    if (tlSpeedValue) tlSpeedValue.textContent = s + 'x';
    if (pendingCapture && pendingCapture.isTimelapse) pendingCapture.timelapseSpeed = s;
    return s;
  }

  function scheduleTimelapseProcess(speed) {
    const s = syncTimelapseSpeedUI(speed);
    if (tlProcessTimer) clearTimeout(tlProcessTimer);
    tlProcessTimer = setTimeout(() => processTimelapseSpeed(s), 350);
  }

  if (tlSpeedSlider) {
    tlSpeedSlider.addEventListener('input', () => {
      if (pendingCapture && pendingCapture.isTimelapse) {
        scheduleTimelapseProcess(parseInt(tlSpeedSlider.value, 10));
      }
    });
  }

  if (tlSpeedInput) {
    tlSpeedInput.addEventListener('input', () => {
      if (!pendingCapture || !pendingCapture.isTimelapse) return;
      scheduleTimelapseProcess(parseInt(tlSpeedInput.value, 10));
    });
    tlSpeedInput.addEventListener('change', () => {
      if (!pendingCapture || !pendingCapture.isTimelapse) return;
      scheduleTimelapseProcess(parseInt(tlSpeedInput.value, 10));
    });
    tlSpeedInput.addEventListener('keydown', (e) => {
      if (e.key === 'Enter' && pendingCapture && pendingCapture.isTimelapse) {
        e.preventDefault();
        scheduleTimelapseProcess(parseInt(tlSpeedInput.value, 10));
      }
    });
  }

  reviewDiscardBtn.addEventListener('click', () => {
    dismissOverlay(() => closeReviewScreen());
  });

  reviewUploadBtn.addEventListener('click', async () => {
    if (!pendingCapture) return;

    if (pendingCapture.isTimelapse) {
      const speed = pendingCapture.timelapseSpeed || parseInt(tlSpeedSlider?.value, 10) || 15;
      reviewUploadBtn.disabled = true;
      try {
        await uploadTimelapseWithSpeed(pendingCapture.blob, speed);
        dismissOverlay(() => closeReviewScreen());
      } catch (e) {
        console.error('[TIMELAPSE ERROR]: ', e);
        showMicroToast('Timelapse failed: ' + (e.message || 'try again'));
      } finally {
        reviewUploadBtn.disabled = false;
      }
      return;
    }

    const { blob, filename, mimetype } = pendingCapture;
    const caption = reviewCaptionInput.value.trim();
    const capY = snapBarY;
    uploadMedia(blob, filename, mimetype, caption, capY < 50 ? 'top' : 'bottom', capY);
    dismissOverlay(() => closeReviewScreen());
  });

  // ─── Upload ───
  async function uploadMedia(blob, filename, mimetype, caption, capPos, capY) {
    uploadProgress.classList.remove('hidden');
    progressFill.style.width = '30%';

    let uploadBlob = blob;
    let captionBurnedIn = false;
    const capText = (caption || '').trim();
    const isImage = mimetype && mimetype.startsWith('image');
    if (capText && isImage) {
      try {
        uploadBlob = await compositeCaptionOnImage(blob, capText, capY);
        captionBurnedIn = true;
      } catch (e) {
        console.error('Caption composite failed:', e);
      }
    }

    const formData = new FormData();
    formData.append('media', uploadBlob, filename);
    formData.append('participantNumber', currentUser.participantNumber);
    formData.append('fullName', currentUser.fullName);
    formData.append('gender', currentUser.gender);
    formData.append('caption', capText);
    formData.append('captionPosition', capPos || 'bottom');
    formData.append('captionYOffset', String(capY != null ? capY : 50));
    if (captionBurnedIn) formData.append('captionBurnedIn', 'true');

    const isVideo = mimetype && mimetype.startsWith('video');
    const controller = new AbortController();
    const timeoutId = setTimeout(() => controller.abort(), isVideo ? 120000 : 60000);

    try {
      progressFill.style.width = '60%';
      const res = await fetch(api('upload'), { method: 'POST', body: formData, signal: controller.signal });
      clearTimeout(timeoutId);
      progressFill.style.width = '90%';
      const data = await res.json();
      if (res.ok) {
        vibrate([50, 30, 50]);
        progressFill.style.width = '100%';
        momentsCaptured++;
        updateMomentsDisplay();
        refreshGalleryThumb();
        setTimeout(() => { uploadProgress.classList.add('hidden'); progressFill.style.width = '0'; }, 800);
      } else {
        showMicroToast(data.error || (isVideo ? 'Video upload failed' : 'Upload failed'));
        uploadProgress.classList.add('hidden'); progressFill.style.width = '0';
      }
    } catch (err) {
      clearTimeout(timeoutId);
      showMicroToast(isVideo ? 'Video upload failed — check connection' : 'Upload failed — check connection');
      uploadProgress.classList.add('hidden'); progressFill.style.width = '0';
    }
  }

  // ─── Gallery Modal ───
  const TRASH_SVG = '<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><polyline points="3 6 5 6 21 6"/><path d="M19 6l-1 14a2 2 0 0 1-2 2H8a2 2 0 0 1-2-2L5 6"/><path d="M10 11v6M14 11v6"/><path d="M9 6V4a2 2 0 0 1 2-2h2a2 2 0 0 1 2 2v2"/></svg>';
  const DOWNLOAD_SVG = '<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><polyline points="7 10 12 15 17 10"/><line x1="12" y1="15" x2="12" y2="3"/></svg>';

  function closeGalleryModal() {
    galleryModal.classList.add('hidden');
  }

  function closeMediaModal() {
    mediaModal.classList.add('hidden');
    mediaModalBody.innerHTML = '';
  }

  galleryBtn.addEventListener('click', () => {
    vibrate(20);
    loadGallery();
    galleryModal.classList.remove('hidden');
    pushOverlay(closeGalleryModal);
  });
  galleryModalClose.addEventListener('click', () => dismissOverlay(closeGalleryModal));
  galleryModal.addEventListener('click', (e) => {
    if (e.target === galleryModal) dismissOverlay(closeGalleryModal);
  });

  async function loadGallery() {
    if (!currentUser) return;
    try {
      const res = await fetch(api('gallery/' + encodeURIComponent(currentUser.participantNumber)));
      const photos = await res.json();
      galleryGrid.innerHTML = '';
      if (!photos.length) { galleryEmpty.classList.remove('hidden'); updateGalleryThumbnail([]); return; }
      galleryEmpty.classList.add('hidden');
      updateGalleryThumbnail(photos);

      photos.forEach((p) => {
        const item = document.createElement('div');
        item.className = 'gallery-item';
        const mediaWrap = document.createElement('div');
        mediaWrap.style.cssText = 'position:relative;width:100%;height:100%;';
        if (p.fileType === 'video') {
          const vid = document.createElement('video');
          vid.src = url('uploads/' + p.filename);
          vid.muted = true;
          vid.preload = 'metadata';
          mediaWrap.appendChild(vid);
          const badge = document.createElement('span');
          badge.className = 'video-badge';
          badge.textContent = '▶';
          mediaWrap.appendChild(badge);
        } else {
          const img = document.createElement('img');
          img.src = url('uploads/' + p.filename);
          img.alt = 'Photo';
          img.loading = 'lazy';
          img.decoding = 'async';
          img.addEventListener('load', () => {
            if (img.naturalWidth > img.naturalHeight) item.classList.add('landscape-item');
          });
          mediaWrap.appendChild(img);
        }
        if (p.caption && !p.captionBurnedIn) {
          applyCaptionOverlay(mediaWrap, p.caption, getCaptionYPercent(p));
        }
        item.appendChild(mediaWrap);

        const actions = document.createElement('div');
        actions.className = 'item-actions';
        actions.innerHTML = `<button class="download-btn" title="Download">${DOWNLOAD_SVG}</button><button class="delete-btn" data-id="${p._id}" title="Delete">${TRASH_SVG}</button>`;
        item.appendChild(actions);
        item.addEventListener('click', (e) => {
          if (e.target.closest('.delete-btn') || e.target.closest('.download-btn')) return;
          openMediaModal(p);
        });
        item.querySelector('.download-btn').addEventListener('click', (e) => { e.stopPropagation(); downloadMedia(p); });
        item.querySelector('.delete-btn').addEventListener('click', (e) => { e.stopPropagation(); deleteMedia(p._id); });
        galleryGrid.appendChild(item);
      });
    } catch (err) { console.error('Gallery load error:', err); }
  }

  async function deleteMedia(id) {
    if (!confirm('Delete this moment?')) return;
    try {
      const res = await fetch(api('media/' + encodeURIComponent(id)), { method: 'DELETE' });
      if (res.ok) {
        vibrate(50);
        momentsCaptured = Math.max(0, momentsCaptured - 1);
        updateMomentsDisplay();
        loadGallery();
      }
    } catch (err) { showMicroToast('Delete failed'); }
  }

  function openMediaModal(p) {
    mediaModalBody.innerHTML = '';
    const wrap = document.createElement('div');
    wrap.className = 'media-wrap';
    if (p.fileType === 'video') {
      const v = document.createElement('video');
      v.src = url('uploads/' + p.filename); v.controls = true; v.autoplay = true;
      wrap.appendChild(v);
      v.addEventListener('loadedmetadata', () => {
        if (v.videoWidth > v.videoHeight) wrap.classList.add('landscape-media');
      });
    } else {
      const img = document.createElement('img');
      img.src = url('uploads/' + p.filename);
      img.decoding = 'async';
      img.addEventListener('load', () => {
        if (img.naturalWidth > img.naturalHeight) wrap.classList.add('landscape-media');
      });
      wrap.appendChild(img);
    }
    if (p.caption && !p.captionBurnedIn) {
      const capEl = document.createElement('div');
      capEl.className = 'snap-modal-caption snap-caption-bar';
      capEl.style.top = getCaptionYPercent(p) + '%';
      capEl.innerHTML = `<span>${escapeHtml(p.caption)}</span>`;
      wrap.appendChild(capEl);
    }
    mediaModalBody.appendChild(wrap);
    const actions = document.createElement('div');
    actions.className = 'media-modal-actions';
    actions.innerHTML = `<button class="media-download-btn">Download</button>`;
    actions.querySelector('.media-download-btn').addEventListener('click', () => downloadMedia(p));
    mediaModalBody.appendChild(actions);
    mediaModal.classList.remove('hidden');
    pushOverlay(closeMediaModal);
  }

  mediaModalClose.addEventListener('click', () => dismissOverlay(closeMediaModal));
  mediaModal.addEventListener('click', (e) => {
    if (e.target === mediaModal) dismissOverlay(closeMediaModal);
  });

  function escapeHtml(str) {
    const div = document.createElement('div');
    div.textContent = str;
    return div.innerHTML;
  }

  checkSession();
})();
